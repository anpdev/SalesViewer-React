import React, { useState } from 'react'
import Map from 'devextreme-react/map';

function Maps(props) {
    return (
        <>
            <div>
                <h4>Route Overview</h4>
                <Map
                defaultZoom={14}
                height={440}
                width="100%"
                controls={true}
                markers={props.markersData}
                routes={props.routesData}
                provider="bing"
                />
            </div>
        </>
    )
}

export default Maps
