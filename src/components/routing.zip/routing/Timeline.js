import React from 'react'
import Scheduler, { Resource,AppointmentDragging } from 'devextreme-react/scheduler';
import '../../css/component/timeline.scss';
function Timeline(props) {
    const currentDate = new Date();
    const views = ['timelineDay', 'timelineWeek', 'timelineMonth'];
    const groups = ['userID'];

    return (
    <React.Fragment>
      <Scheduler
              timeZone="America/Los_Angeles"
              dataSource={props.appointments}
              views={views}
              defaultCurrentView="timelineWeek"
              defaultCurrentDate={currentDate}
              height={500}
              groups={groups}
              cellDuration={60}
              firstDayOfWeek={0}
              startDayHour={9}
              endDayHour={24}
              editing={true}>
                <AppointmentDragging
                    group={props.draggingGroupName}
                    onRemove={props.onAppointmentRemove}
                    onAdd={props.onAppointmentAdd}
                />
                <Resource
                    fieldExpr="userID"
                    allowMultiple={true}
                    dataSource={props.resourcesData}
                    label="Owner"
                    useColorAsDefault={ true }
                />
          </Scheduler>
    </React.Fragment>
  )
}

export default Timeline
