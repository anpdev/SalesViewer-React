export const tasks = [
  {
    orderId: '1111',
    text : "gaurav",
    description : "Western Spring"
  }, {
    orderId: '2222',
    text : "lukesh",
    description : "Western Spring"

  }, {
    orderId: '3333',
    text : "rishi",
    description : "Western Spring"

  }, {
    orderId: '4444',
    text : "ashish",
    description : "Western Spring"

  }, {
    orderId: '5555',
    text : "anup",
    description : "Western Spring"
    
  }, {
    orderId: '6666',
    text : "nikhesh",
    description : "Western Spring"
  }, {
    orderId: '7777',
    text : "pradeep",
    description : "Western Spring"
  }, {
    orderId: '8888',
    text : "jayant",
    description : "Western Spring"
  }, {
    orderId: '9999',
    text : "trap",
    description : "Western Spring"
  }, {
    orderId: '10000',
    text : "devendra",
    description : "Western Spring"
  },
];

export const resourcesData = [
    {
      text: 'Samantha Bright',
      id: 1,
      color: '#56ca85',
    }, {
      text: 'John Heart',
      id: 2,
      color: '#56ca85',
    }, {
      text: 'Todd Hoffman',
      id: 3,
      color: '#56ca85',
    }, {
      text: 'Sandra Johnson',
      id: 4,
      color: '#56ca85',
    },
  ];
  
  export const appointments = [{
    text: 'Google AdWords Strategy',
    userID: [2],
    startDate: new Date('2022-04-11T16:00:00.000Z'),
    endDate: new Date('2022-03-27T17:00:00.000Z'),
    
  }, {
    text: 'New Brochures',
    userID: [4],
    startDate: new Date('2022-03-27T18:00:00.000Z'),
    endDate: new Date('2021-02-01T19:00:00.000Z'),
   
  }, {
    text: 'Brochure Design Review',
    userID: [1],
    startDate: new Date('2022-03-27T20:00:00.000Z'),
    endDate: new Date('2021-02-01T21:00:00.000Z'),
  
  }, {
    text: 'Website Re-Design Plan',
    userID: [3],
    startDate: new Date('2022-03-27T18:00:00.000Z'),
    endDate: new Date('2021-02-02T19:00:00.000Z'),
   
  } ];
  