import React from 'react';
import { Routes, Route } from "react-router-dom";
import DashboardLayout from "./common/DashboardLayout";
import RevenueByProduct from "./common/RevenueByProduct";
import RevenueByCategory from "./common/RevenueByCategory";
import RevenueByChannels from "./common/RevenueByChannels";
import Products from './common/Products';
import Sales from './common/Sales';
import Customers from './common/Customers';

function Dashboard() {
    return(
      <Routes>  
        <Route path="/" element={<DashboardLayout />}>
          <Route path="/product" index element={  <RevenueByProduct />} />
          <Route path="/category" element={  <RevenueByCategory />} />
          <Route path="/channels" element={  <RevenueByChannels />} />
          <Route path="/products" element={  <Products />} />
          <Route path="/sales" element={  <Sales />} />
          <Route path="/customers" element={  <Customers />} />
        </Route>
      </Routes> 
      );
         
      
    }
export default Dashboard 
