import React, {useState,useEffect} from 'react';
import useAxios from "../../../../hooks/useAxios"
import RangeSelector, {
  Margin, Chart, CommonSeriesSettings, Series, Scale, TickInterval, MinorTickInterval, SliderMarker,
} from 'devextreme-react/range-selector';
import moment from 'moment';
function RangeSlider(props) {  
    
    let strDate = moment().startOf('year').format('MM/DD/YYYY');
    let endDate = moment().format('MM/DD/YYYY');
    const axios = useAxios(); 
    const defaultValue = [strDate, endDate];
   
    const[rangeDataSource,setRangeDataSource] = useState({});
    const onRangeChanged = (e) => {
      console.log(e.value[0], e.value[1])
      let strDate = moment(e.value[0]).format('YYYY-MM-DD');
      let endDate = moment(e.value[1]).format('YYYY-MM-DD');
      props.sendRangeToParent({strDate:strDate,endDate,endDate});
  }

  useEffect(async() => {  
    let rangeData = await axios.get("/dashboard/rangeselector/?startDate=2022-01-01&endDate=2022-12-31");
      if(rangeData.data.success){   
        
        setRangeDataSource(rangeData.data.data);
       
      }
  }, []);


    return (
      <>
     
      <RangeSelector
        id="range-selector"
        dataSource={rangeDataSource}
        defaultValue={defaultValue}
        onValueChanged={onRangeChanged}
      >
        <Margin top={50} />
        <Chart>
          <CommonSeriesSettings type="line" argumentField="SaleDate" />
          <Series valueField="Sales" color="red" />
         
        </Chart>
        <Scale valueType="datetime" startValue={defaultValue[0]} endValue={defaultValue[1]}>
          <TickInterval months={1} />
          <MinorTickInterval days={2} />
        </Scale>
        <SliderMarker format="monthAndDay" />
      </RangeSelector>
      </>  
    );
  }
  export default RangeSlider;