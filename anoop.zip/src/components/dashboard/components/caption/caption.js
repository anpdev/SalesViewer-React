import React from 'react';
import './caption.scss';
 function Caption(props) {
  
    return (
        <>
           <div className="caption">
          DAILY SALE { props.criteria.toUpperCase()}
       </div>
        </>
    )
}

export default Caption
