import React,{ useState, useEffect } from 'react';
import RangeSlider from "../rangeselector/rangeselector";  
import useAxios from "../../../../hooks/useAxios"
import {
  Chart,CommonSeriesSettings,  ArgumentAxis, ValueAxis
} from 'devextreme-react/chart'; 
import PieChart, {
  Series,
  Legend,
  Label,
  Font, 
  Format, 
  Connector,
  Tooltip,
} from 'devextreme-react/pie-chart';
import moment from 'moment';


import './sales-by-range.scss'; 

function SalesByRange(props){
     
    const axios = useAxios();
  
    const[range,setRange] = useState({});

    const customizeTooltip = (arg) => {  
        return {
          text: `${arg.argumentText} <br> $${arg.valueText} `,
          
        };
      };
   const customizeTooltipBar =(arg) => {

    return {
      text: `${arg.argumentText} <br> $${arg.valueText} `,
      
    };
   }
   const customizePoint = () => {
    //let color = this.themeService.getColor(this.category, pointInfo.argument);
     let color = '#'+Math.random().toString(16).substr(2,6);
     return {
         color: color,
         hoverStyle: {
             color: color,
             hatching: {
                 opacity: 0
             }
         }
     };
 } 

 const customizeLable =(arg) => {
  return arg.percentText;
 } 

 const sendRangeToParent= (range)=>{
  setRange(range);
 } 

 const[dataSource,setDataSource] = useState({});
 const[pieDataSource,setPieDataSource] = useState({});
 const[barDataSource,barPieDataSource] = useState({});
 useEffect(async() => {  
  let strDate = (range.strDate!==undefined) ? range.strDate : moment().startOf('year').format('MM/DD/YYYY');
  let endDate = (range.endDate!==undefined) ? range.endDate : moment().format('MM/DD/YYYY'); 
   
  let rangeData = await axios.get('/dashboard/productsalesbyrange/?startDate='+strDate+'&endDate='+endDate);
    if(rangeData.data.success){   
      setPieDataSource(rangeData.data.data);
      barPieDataSource(rangeData.data.data);
      console.log(dataSource)
    }
}, [range]);

 return(
     <>
     <div className="sales-by-range">
            <div className="doughnut-container"> 
            <div className="title">PRODUCT SALES BY RANGE</div>

            <PieChart
                className='sector' style={{height: '280px'}}
                dataSource={pieDataSource}
                resolveLabelOverlapping="shift"
                sizeGroup="piesGroup"
                type="doughnut"
                innerRadius={0.65}
                
            > 
                <Series
                argumentField="Criteria"
                valueField="Sales"
                
                >
                <Label visible={true} backgroundColor="transparent"  customizeText={customizeLable}>
                <Font size={12} color="#909090"></Font>
                <Connector visible={false} width={0}></Connector>
                </Label> 
                </Series>
                
                <Tooltip
                enabled={true}
                customizeTooltip={customizeTooltip}
                > 
                </Tooltip> 
                <Legend visible={false}></Legend> 
            </PieChart>
            </div>
      
        <div className="bar-container">
        <div className="year">2022</div>
        <div className="title">PRODUCT SALES BY RANGE</div>
        <Chart className="chart" style={{height: '190px'}}
         rotated ={true}
        
         customizePoint = {customizePoint}
         dataSource={barDataSource}>
        
        <ArgumentAxis> 
           <Label visible={false} placeholderSize={40}></Label> 
        </ArgumentAxis>
           
        <ValueAxis
         valueMarginsEnabled={false}
         axisDivisionFactor={80}
         placeholderSize={30}
         > 
           <Label indentFromAxis={5}>
           <Format size={12} type="currency"></Format>
                
           </Label>
        </ValueAxis>
        <CommonSeriesSettings argumentField="Criteria" valueField="Sales" type="bar" />
        {/* <SeriesTemplate nameField="Criteria" /> */}
        <Series
         
          argumentField="Criteria"
          valueField="Sales"
          type="bar"
          color="#ffaa66" />
       
        <Tooltip
          enabled={true}
          customizeTooltip={customizeTooltipBar}
        />  
         
        <Legend visible={false}></Legend>
        </Chart>
        </div>   

     <RangeSlider range={range} sendRangeToParent={sendRangeToParent}/>  
     
    </div>
    </>
 )
}
export default SalesByRange