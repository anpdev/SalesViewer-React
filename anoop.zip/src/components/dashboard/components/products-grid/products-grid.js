import React, { useRef, useState } from "react";
import DataGrid, {
  Column,
  Pager,
  Paging,
  Selection,
  
} from 'devextreme-react/data-grid';
import CustomStore from 'devextreme/data/custom_store';
import useAxios from "../../../../hooks/useAxios";
import 'devextreme/dist/css/dx.light.css';
import RangeSlider from "../rangeselector/rangeselector";


function ProductGrid(props) {
  
    const axios = useAxios();
    const Gridref = useRef(null);
    
  
    const isNotEmpty = (value)  => {
      return value !== undefined && value !== null && value !== '';
    }
    const store = new CustomStore({
      key: 'product_id',
      async load(loadOptions) {
        let params = '?';
        [
          'skip',
          'take',
          'sort',
          'filter',
          'group'
        ].forEach((i) => {
          if (i in loadOptions && isNotEmpty(loadOptions[i])) { params += `${i}=${JSON.stringify(loadOptions[i])}&`; }
        });
        params = params.slice(0, -1);
        try {
         const response = await axios.get('/dashboard/productgrid/?startDate=2022-01-02&endDate=2022-06-02');
         return ({
            data: response.data.data.values,
            totalCount: parseInt(response.data.data.total_count)
          });
        } catch {
          throw new Error('Data Loading Error');
        }
      },
    });
    const selectionChanged = (e) => {
        let id = e.selectedRowsData[0].product_id;
        props.onSelectionChange(id)
    }
    return (
        <>  
            <React.Fragment>
            <div className='container-fluid' style={{ padding: '0px 35px', background: '#ffffff'}}>
                
            <DataGrid ref ={Gridref}
            dataSource={store}
            keyExpr={'product_id'}
            allowColumnReordering={true}
            allowColumnResizing={true}
            hoverStateEnabled={true}
            remoteOperations={true}
            showRowLines= {true}
            onSelectionChanged={selectionChanged}
            >
            
            <Selection mode="single" />
            <Column
                dataField={'NAME'}
                allowSorting={true}
                allowFiltering={true}
                allowGrouping={false}
                allowReordering={false}
                
            />
            <Column
                dataField={'description'}
                allowSorting={true}
                allowGrouping={false}
                allowReordering={false}
            />
            <Column
                dataField={'baseCost'}
                allowSorting={true}
                allowGrouping={false}
                allowReordering={false}
            />
            <Column
                dataField={'listPrice'}
                allowSorting={true}
                allowGrouping={false}
                allowReordering={false}
            />

            <Column
                dataField={'unitsInInventory'}
                allowFiltering={true}
                allowGrouping={false}
                allowReordering={false}
            />
            <Column
                dataField={'unitsInManufacturing'}
                allowSorting={true}
                allowFiltering={true}
                allowGrouping={false}
                allowReordering={false}
            />
            <Column
                dataField={'last_sale_date'}
                allowSorting={true}
                allowFiltering={true}
                allowGrouping={false}
                allowReordering={false}
            />
            
            <Pager allowedPageSizes={[20, 50, 100]} showPageSizeSelector={true} />
            <Paging defaultPageSize={5} />
            </DataGrid>
            </div>
            </React.Fragment>
            <div className='gray-line'>
            <RangeSlider />  
     
      </div> 
            </>
  );
}

export default ProductGrid