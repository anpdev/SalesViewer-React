 
import React from 'react'

import {
  Chart, Series, CommonSeriesSettings, Tooltip ,Legend
} from 'devextreme-react/chart'; 
import './ComparingBars.scss';
import Parameters from "../../components/parameters/Parameters"; 
import DateSwitcher from "../../components/date-switcher/DateSwitcher"; 
import Caption from "../../components/caption/caption";
function ComparingBars(props) { 
 const sendDateToParent = (date,criteria) => { // the callback. Use a better name
  props.sendDateToPParent(date,criteria);  
};
  const customizeTooltip = (arg) => { 
    return {
      text: `${arg.argumentText} <br> $${arg.totalText} <br> ${arg.seriesName}`,
      
    };
  };
  
  const customizePoint = () => {
       //let color = this.themeService.getColor(this.category, pointInfo.argument);
        let color = '#'+Math.random().toString(16).substr(2,6);
        return {
            color: color,
            hoverStyle: {
                color: color,
                hatching: {
                    opacity: 0
                }
            }
        };
    }


  return ( 
    
     <>
         
    <Caption criteria={props.criteria}/>   
      
    <Parameters criteria={props.criteria} parameter={props.parameter}/> 
       
     
    <DateSwitcher dateFormat={props.dateFormat} criteria={props.criteria} sendDateToParent={sendDateToParent}/>
       
    <Chart className="chart"
      dataSource={props.Source}
      customizePoint={customizePoint}
     >
      <CommonSeriesSettings
        argumentField="Criteria"
        type="bar"
        hoverMode="allArgumentPoints"
        selectionMode="allArgumentPoints"
      >

      </CommonSeriesSettings>
       <Series
          argumentField="Criteria"
          valueField="TodaySales"
          name="Today"
         />
        <Series
          argumentField="Criteria"
          valueField="YesterdaySales"
          name="Yesterday"
         />
        <Tooltip
          enabled={true}
          customizeTooltip={customizeTooltip}
        />  
         
        <Legend visible={false}></Legend>
    </Chart>
    </>  
        
  );
}
export default ComparingBars;