import React, { useState ,useEffect } from 'react'
import Moment from 'react-moment';
import moment from 'moment';

import './DateSwitcher.scss';
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faCaretLeft, faCaretRight} from "@fortawesome/free-solid-svg-icons";
//const DateSwitcher = ({sendDataToParent }) => { 
 function DateSwitcher(props) { 
  let currentDate = new Date();
  let format = (props.dateFormat == 'day') ? "MMMM D YYYY" : "MMMM";  
  let[date,setDate] = useState(currentDate);
  let[criteria,setCriteria] = useState('');
  
  const updateDate=(param,criteria,format)=>{ 

    if(format=='day'){ date = moment(date).add(param, 'd'); }
    else {date = moment(date).add(param, 'M');}
    setCriteria(criteria);
     
     
     setDate(date);
     props.sendDateToParent(date,criteria);
  }

  return (
        <>
        <div className='switcher'>
          <FontAwesomeIcon icon={faCaretLeft} onClick={() => updateDate(-1,props.criteria,props.dateFormat)}></FontAwesomeIcon>          
          <Moment format={format}>{date}</Moment>
          <FontAwesomeIcon icon={faCaretRight} onClick={() => updateDate(1,props.criteria,props.dateFormat)}></FontAwesomeIcon>
        </div>
        </>
    )
}
export default DateSwitcher