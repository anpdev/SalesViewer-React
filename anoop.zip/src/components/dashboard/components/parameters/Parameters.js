import React, {useEffect,useState} from 'react';
import './Parameters.scss';
//import useAxios from "../../../../hooks/useAxios"
 function Parameters(props) {
 
    return (
        <>
        <div className="line">
          <div className="parameters">  
           <div className="parameter-name" > Today</div>
           <div className="parameter currency"> {props.parameter.TodaySales} </div>
        </div>
        <div className=   "parameters">  
           <div className="parameter-name" > Yesterday </div>
           <div className="parameter currency" > {props.parameter.YesterdaySales} </div>
        </div>
        <div className="parameters">  
           <div className="parameter-name" > Last Week </div>
           <div className="parameter currency" > {props.parameter.LastWeekSales} </div>
        </div>
      </div>   
        </>
    )
}

export default Parameters
