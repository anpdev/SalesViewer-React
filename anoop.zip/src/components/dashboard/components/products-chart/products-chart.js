import React from 'react';
 
import PieChart, {
  Series,
  Legend,
  Tooltip,
} from 'devextreme-react/pie-chart';
import './products-chart.scss'
function ProductsChart(props){
    let dataSource = props.Source;  
   

    const customizeTooltip = (arg) => {  
        console.log(arg);
        return {
          text: `${arg.argumentText} <br> $${arg.valueText} <br> ${arg.seriesName}`,
          
        };
      };


 return(
     <>
      
       <PieChart
        className='sector'
        dataSource={dataSource}
        type="doughnut"
        innerRadius={0.65}
      > 
        <Series
          argumentField="Criteria"
          valueField="Sales"
        >
        
        </Series>
         
         <Legend horizontalAlignment="center" verticalAlignment="bottom" />
          <Tooltip
          enabled={true}
          customizeTooltip={customizeTooltip}
           > 
        </Tooltip>  
      </PieChart>
       
     </>
 )
}
export default ProductsChart