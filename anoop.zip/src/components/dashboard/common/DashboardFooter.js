import React from "react";

function Footer() {
  return (
    <div id="footer_wrapper">
     
    </div>
  );
}

export default Footer;
