import React, { useRef } from "react";
import ProductGrid from "../components/products-grid/products-grid";
import ProductsChart from "../components/products-chart/products-chart";
import { PieSource } from './pie-data';
import './products.scss';
function Products() { 
  const handleOnSelection =() => {
     console.log('from papa');
  }
  return ( 
     <>
    
     <ProductGrid onSelectionChange={handleOnSelection}/>
       {/* <div className="gray-line">
        <div className="product-info">
          <div className="info">   

            lorem ipsum dollor sit amet
            lorem ipsum dollor sit amet
            lorem ipsum dollor sit amet
            lorem ipsum dollor sit amet
          </div>
        <div className="charts">
        <div className="products-pie-container">
               <ProductsChart Source={PieSource}/>
               <ProductsChart Source={PieSource}/>
               <ProductsChart Source={PieSource}/>
               </div>    
            </div>    
        </div>
    </div>      */}
     </>
  );
}

export default Products;
