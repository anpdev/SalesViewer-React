import React from 'react'
 function Customers() {
   var a;
    return (
        <>
          This is dashboard customers page
        </>
    )
}

export default Customers
