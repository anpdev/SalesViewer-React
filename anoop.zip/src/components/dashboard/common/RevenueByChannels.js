import React from 'react'
function RevenueByChannels() {
    return (
        <>
         
          This is revenue by channels
          </>
    )
}

export default RevenueByChannels
