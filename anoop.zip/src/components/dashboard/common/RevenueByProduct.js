import React, { useState ,useEffect } from 'react'
import ComparingBars from "../components/comparing-bars/ComparingBars"; 
import SalesByRange from "../components/sales-by-range/sales-by-range"; 
import useAxios from "../../../hooks/useAxios" 
 
import moment from 'moment';
//import useAxios from "../../../hooks/useAxios";

import { PieSource } from './pie-data';
import { rangeDataSource } from './slider-data';

function RevenueByProduct() {
   
const axios = useAxios();
const [date, setDate] = useState({}); // the lifted state
const [criteria, setCriteria] = useState({}); // the lifted state
const [leftBar, setLeftBar] = useState({});
const [rightBar, setRightBar] = useState({});
const [leftParameters, SetLeftParameters] = useState({});
const [rightParameters, SetRightParameters] = useState({});
const sendDateToPParent = (date,criteria) => { // the callback. Use a better name
 setDate(date);
 setCriteria(criteria);
};
useEffect(async() => {  
  let parameter = await axios.get("/dashboard/revenueByProduct/?now="+moment(date).format('YYYY-MM-DD'));
    if(parameter.data.success){ 
      SetLeftParameters({ TodaySales: parameter.data.data.TodaySales,
                    YesterdaySales: parameter.data.data.YesterdaySales,
                    LastWeekSales: parameter.data.data.LastWeekSales
                  });
      SetRightParameters({ TodaySales: parameter.data.data.ThisMonthUnits,
                  YesterdaySales: parameter.data.data.LastMonthUnits,
                  LastWeekSales: parameter.data.data.YtdUnits
      });            
    }
}, []);

useEffect(async() => {  
  if(criteria=='product') {
  let product = await axios.get("/dashboard/revenueByProduct/?twoDays="+moment(date).format('YYYY-MM-DD'));
    if(product.data.success){ 
      setLeftBar(product.data.data);
    }
  }
  if(criteria=='category') {
  let category = await axios.get("/dashboard/revenueByProduct/?twoMonths="+moment(date).format('YYYY-MM-DD'));
    if(category.data.success) { 
      setRightBar(category.data.data);  
    }
}
}, [date,criteria]);
useEffect(async() => {  
  
  let product = await axios.get("/dashboard/revenueByProduct/?twoDays="+moment(date).format('YYYY-MM-DD'));
    if(product.data.success){ 
      setLeftBar(product.data.data);
    }
  
  let category = await axios.get("/dashboard/revenueByProduct/?twoMonths="+moment(date).format('YYYY-MM-DD'));
    if(category.data.success) { 
      setRightBar(category.data.data);  
    
}
}, []);



 return (
    <>
      <div className="header">
          <h3>REVENUE BY PRODUCT</h3>
      </div>  
      <div className='bars'>    
        <div className='left-bar'>
           <ComparingBars dateFormat='day' criteria="product" sendDateToPParent={sendDateToPParent} Source={leftBar} parameter={leftParameters} />
        </div>
      <div className='right-bar'>
           <ComparingBars dateFormat='month' criteria="category" sendDateToPParent={sendDateToPParent} Source={rightBar} parameter={rightParameters} />
         </div>
        </div>
      <div className='gray-line'>
        <SalesByRange pie={PieSource} bar={PieSource} range={rangeDataSource} />
      </div>  
   </>   
 );

}

export default RevenueByProduct