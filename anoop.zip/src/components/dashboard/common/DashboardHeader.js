import React,{useEffect,useState} from "react";
import {  NavLink } from "react-router-dom";

import { Navbar, Nav} from "react-bootstrap";
//import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
//import {faTachometer, faServer, faPhoneSquare, faEnvelope, faCartPlus, faFileText, faTruck, faBook, faCog, faInfoCircle} from "@fortawesome/free-solid-svg-icons";
//import   '../../css/component/header.scss';
//import useConfig from "../../hooks/useConfig";
//import HeaderTop from './HeaderTop';
//import useAxios from "hooks/useAxios";
//import useAuth from "../../hooks/useAuth";

import useConfig from "../../../hooks/useConfig";
  
function DashboardHeader() {
const conf = useConfig(); 
  
  return (
    <>
     <Navbar className="secondaryNavbar" collapseOnSelect expand="lg" variant="light">
        <Navbar.Collapse id="responsive-navbar-nav-secondary">
          <Nav>
               <NavLink className="nav-link" to="product">
                  Revenue by product
              </NavLink> 
              <NavLink className="nav-link" to="category">
                  Revenue by category
              </NavLink> 
              <NavLink className="nav-link" to="channels">
                  Revenue by channels
              </NavLink> 
              <NavLink className="nav-link" to="products">
                  products
              </NavLink>
              <NavLink className="nav-link" to="sales">
                  sales
              </NavLink> 
              <NavLink className="nav-link" to="customers">
                  customers
              </NavLink>  
          </Nav>
        </Navbar.Collapse>
    </Navbar>
    </>
  );
}

export default DashboardHeader;
