import React from "react";

function DashboardFooter() {
  return (
    <div id="footer_wrapper">
     
    </div>
  );
}

export default DashboardFooter;
