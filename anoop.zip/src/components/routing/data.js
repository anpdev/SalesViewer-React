export const tasks = [
  {
    account_id: '12222121',
    text : "gaurav",
    description : "Western Spring"
  }, {
    account_id: '131333',
    text : "lukesh",
    description : "Western Spring"

  }, {
    account_id: '1114444',
    text : "rishi",
    description : "Western Spring"

  }, {
    account_id: '15555',
    text : "ashish",
    description : "Western Spring"

  }, {
    account_id: '116666',
    text : "anup",
    description : "Western Spring"
    
  }, {
    account_id: '177777',
    text : "nikhesh",
    description : "Western Spring"
  }, {
    account_id: '1111111111188',
    text : "pradeep",
    description : "Western Spring"
  }, {
    account_id: '1999',
    text : "jayant",
    description : "Western Spring"
  }, {
    account_id: '4343443',
    text : "trap",
    description : "Western Spring"
  }, {
    account_id: '34434',
    text : "devendra",
    description : "Western Spring"
  },
];

export const resourcesData = [
    {
      text: 'Samantha Bright',
      id: 1,
      color: '#56ca85',
    }, {
      text: 'John Heart',
      id: 2,
      color: '#56ca85',
    }, {
      text: 'Todd Hoffman',
      id: 3,
      color: '#56ca85',
    }, {
      text: 'Sandra Johnson',
      id: 4,
      color: '#56ca85',
    },
  ];
  
  export const appointments = [{
    text: 'Google AdWords Strategy',
    userID: [2],
    startDate: new Date('2022-04-11T16:00:00.000Z'),
    endDate: new Date('2022-03-27T17:00:00.000Z'),
    
  }, {
    text: 'New Brochures',
    userID: [4],
    startDate: new Date('2022-03-27T18:00:00.000Z'),
    endDate: new Date('2021-02-01T19:00:00.000Z'),
   
  }, {
    text: 'Brochure Design Review',
    userID: [1],
    startDate: new Date('2022-03-27T20:00:00.000Z'),
    endDate: new Date('2021-02-01T21:00:00.000Z'),
  
  }, {
    text: 'Website Re-Design Plan',
    userID: [3],
    startDate: new Date('2022-03-27T18:00:00.000Z'),
    endDate: new Date('2021-02-02T19:00:00.000Z'),
   
  } ];
  